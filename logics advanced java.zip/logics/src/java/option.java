
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns={"/option"})
public class option extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            String option=request.getParameter("ddl");
            
            HttpSession ht=request.getSession(true);
            ht.setAttribute("value",option);
            
//            out.println("<!DOCTYPE html>\n" +
//"<html>\n" +
//"    <head>\n" +
//"        <title>TODO supply a title</title>\n" +
//"        <meta charset=\"UTF-8\">\n" +
//"        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">\n" +
//"    </head>\n" +
//"    <body>"
//                   +" <form action=\"logic\">\n" +
//"            Enter Number:\n" + " <input type=\"text\" value=\""+option+"\" name=\"t1\">\n" +
//"      </form>\n" +
//"    </body>\n" +
//"</html>");
            response.sendRedirect("logic");
        }
    } 

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
